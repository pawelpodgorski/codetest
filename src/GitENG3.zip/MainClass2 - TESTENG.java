// Test comment to test scheduler
public class MainClass {

	public static void aMethod(String s1,String s2,String s3,String s4,String s5,String s6,String s7,String s8){
		
		
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	System.out.println("Hello WOrld");
	
		try{
			//updated by role: engineer 4/19
			int x = 10/4;
			System.out.println("the value of x: " + x);
	
		}catch(Exception e){
		}
	}
}
