pi = 3.14159

my_fname = 'TestF'
my_lname = 'TestL'

print(my_fname, my_lname, sep='\t')


print('{:.4f} {:.4f} {:.8f}'.format(pi, pi, pi))

print('%s ', format(my_name) )



